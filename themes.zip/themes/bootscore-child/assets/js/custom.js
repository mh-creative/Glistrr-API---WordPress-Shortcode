jQuery(function ($) {

    // Do stuff here

}); // jQuery End
