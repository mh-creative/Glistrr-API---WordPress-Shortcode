
<!-- bS Isotope -->
<?php _e('All','bootscore'); ?>
<?php _e('Nothing found','bootscore'); ?>

<!-- bS Share Buttons -->
<?php _e('Look what I found: ','bootscore'); ?>

<!-- bS Cookie Banner -->
<?php esc_html_e('Cookies help us deliver our services. By using our services, you agree to our use of cookies.', 'bootscore'); ?>
<?php esc_html_e('/privacy-policy', 'bootscore'); ?>
<?php esc_html_e('More Information', 'bootscore'); ?>
<?php esc_html_e('Accept', 'bootscore'); ?>		

<!-- bS Dark Mode -->
<?php _e('Toggle theme', 'bootscore'); ?>
<?php _e('Light', 'bootscore'); ?>
<?php _e('Dark', 'bootscore'); ?>
<?php _e('Auto', 'bootscore'); ?>

<!-- bS Swiper -->
<?php _e('You might also like', 'bootscore'); ?>